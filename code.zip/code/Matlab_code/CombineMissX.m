function CombineMissX(ComPDBID,XrayPDBID,OutputPDBID)

switch XrayPDBID
    case '1ctr.pdb'
        ModelPDBID='1ctrModel.pdb';
        partn=2;
        whn=148;
        knownind=[1:74 81:147];
        part1=75:80;
        ch1=[73 74 81 82];
        part2=148;
        ch2=[144 145 146 147];
    case '2rkk.pdb'
        ModelPDBID='2rkkModel.pdb';
        partn=1;
        whn=167;
        knownind=[1:64 76:167];
        part1=65:75;
        ch1=[63 64 76 77];
    case '2sak.pdb'
        ModelPDBID='2sakModel.pdb';
        partn=1;
        whn=136;
        knownind=[16:136];
        part1=1:15;
        ch1=[16 17 18 19];
    case '1gsv.pdb'
        ModelPDBID='1gsvModel.pdb';
        partn=1;
        whn=125;
        knownind=4:125;
        part1=1:3;
        ch1=[4 5 6 7];
    case '5wlb.pdb'
        ModelPDBID='5wlbModel.pdb';
        partn=1;
        whn=166;
        knownind=[1:30 38:166];
        part1=31:37;
        ch1=[29 30 38 39];
    case '2vrw.pdb'
        ModelPDBID='2vrwModel.pdb';
        partn=1;
        whn=184;
        knownind=1:177;
        part1=178:184;
        ch1=[174 175 176 177];
    case '3sd6.pdb'
        ModelPDBID='3sd6Model.pdb';
        partn=1;
        whn=89;
        knownind=[1:66 70:89];
        part1=67:69;
        ch1=[65 66 70 71];
    case '1ey4.pdb'
        ModelPDBID='1ey4Model.pdb';
        partn=2;
        whn=149;
        knownind=6:141;
        part1=1:5;
        ch1=[6 7 8 9];
        part2=142:149;
        ch2=[138 139 140 141];
    case '2zr4.pdb'
        ModelPDBID='2zr4Model.pdb';
        partn=2;
        whn=163;
        knownind=[6:39 45:163];
        part1=1:5;
        ch1=[6 7 8 9];
        part2=40:44;
        ch2=[38 39 45 46];
    case '1avs.pdb'
        ModelPDBID='1avsModel.pdb';
        partn=2;
        whn=90;
        knownind=7:87;
        part1=1:6;
        ch1=[7 8 9];
        part2=88:90;
        ch2=[84 85 86 87];
end

TemComPDB=pdbread(ComPDBID);
TemXrayPDB=pdbread(XrayPDBID);
TemModel=pdbread(ModelPDBID);
% Tempart1=pdbread(miss1ID);
% Tempart2=pdbread(miss2ID);
% Tempart3=pdbread(miss3ID);

nCom=length(TemComPDB.Model.Atom);
nPDB=length(TemXrayPDB.Model.Atom);
nMol=length(TemModel.Model.Atom);
% npart1=length(Tempart1.Model.Atom);
% npart2=length(Tempart2.Model.Atom);
% npart3=length(Tempart3.Model.Atom);

% ��ModelΪ��׼�������ֵ�ָ��
WhX=zeros(nMol,3);
% ��֪����
Molknownind=[];
MolknownX=[];
for i=1:nMol
    if ismember(TemModel.Model.Atom(i).resSeq,knownind)
        Molknownind=[Molknownind;i];
        MolknownX=[MolknownX;TemModel.Model.Atom(i).X TemModel.Model.Atom(i).Y TemModel.Model.Atom(i).Z];
    end
end
WhX(Molknownind,:)=MolknownX;
D0=X2D(WhX);
%���������
Molpart1atomind=[];
for i=1:nMol
    if ismember(TemModel.Model.Atom(i).resSeq,part1)
        Molpart1atomind=[Molpart1atomind;i];        
    end
end
nMolpart1atom=size(Molpart1atomind,1);

Compart1atomind=[];
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,part1)
        Compart1atomind=[Compart1atomind;i];        
    end
end
nCompart1atom=size(Compart1atomind,1);
% ��ȷ��ŵļ�������
Com_PDBind1=[];
for i=1:nCompart1atom
    for j=1:nMolpart1atom
        if strcmp(TemComPDB.Model.Atom(Compart1atomind(i)).AtomName,TemModel.Model.Atom(Molpart1atomind(j)).AtomName) ...
                && TemComPDB.Model.Atom(Compart1atomind(i)).resSeq==TemModel.Model.Atom(Molpart1atomind(j)).resSeq
            Com_PDBind1=[Com_PDBind1;Compart1atomind(i) Molpart1atomind(j)];
        end
    end
end
n_Com_PDBind1=size(Com_PDBind1,1);

if n_Com_PDBind1~=nMolpart1atom
    error('Some atoms are not matched in part1')
    a1=setdiff(Molpart1atomind,Com_PDBind1(:,2)); %��ʾtemModel��û�е�
end
orderCom1=zeros(nMol,3);
for i=1:n_Com_PDBind1
    orderCom1(Com_PDBind1(i,2),:)=[TemComPDB.Model.Atom(Com_PDBind1(i,1)).X ...
        TemComPDB.Model.Atom(Com_PDBind1(i,1)).Y TemComPDB.Model.Atom(Com_PDBind1(i,1)).Z];
end


% chatom={'N' 'CA' 'C' 'O'};
chatom={ 'CA'};
chcom1=[];    % N CA C O
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,ch1) ...
            && ismember(TemComPDB.Model.Atom(i).AtomName,chatom)
        chcom1=[chcom1;i TemComPDB.Model.Atom(i).X TemComPDB.Model.Atom(i).Y TemComPDB.Model.Atom(i).Z];
    end
end

chpdb1=[];
for i=1:nPDB
    if ismember(TemXrayPDB.Model.Atom(i).resSeq,ch1) ...
            && ismember(TemXrayPDB.Model.Atom(i).AtomName,chatom)
        chpdb1=[chpdb1;i TemXrayPDB.Model.Atom(i).X TemXrayPDB.Model.Atom(i).Y TemXrayPDB.Model.Atom(i).Z];
    end
end
[xc1,yc1,Q1]=TQofB2A(chpdb1(:,2:4),chcom1(:,2:4));
part1X=orderCom1(Molpart1atomind,:);
TQpart1=part1X-repmat(yc1,size(part1X,1),1);
TQpart1=TQpart1*Q1;
TQpart1=TQpart1+repmat(xc1,size(part1X,1),1);
WhX(Molpart1atomind,:)=TQpart1;
 
if partn>=2
Molpart2atomind=[];
for i=1:nMol
    if ismember(TemModel.Model.Atom(i).resSeq,part2)
        Molpart2atomind=[Molpart2atomind;i];        
    end
end
nMolpart2atom=size(Molpart2atomind,1);

Compart2atomind=[];
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,part2)
        Compart2atomind=[Compart2atomind;i];        
    end
end
nCompart2atom=size(Compart2atomind,1);
% ��ȷ��ŵļ�������
Com_PDBind2=[];
for i=1:nCompart2atom
    for j=1:nMolpart2atom
        if strcmp(TemComPDB.Model.Atom(Compart2atomind(i)).AtomName,TemModel.Model.Atom(Molpart2atomind(j)).AtomName) ...
                && TemComPDB.Model.Atom(Compart2atomind(i)).resSeq==TemModel.Model.Atom(Molpart2atomind(j)).resSeq
            Com_PDBind2=[Com_PDBind2;Compart2atomind(i) Molpart2atomind(j)];
        end
    end
end
n_Com_PDBind2=size(Com_PDBind2,1);

if n_Com_PDBind2~=nMolpart2atom
    error('Some atoms are not matched in part2')
    a2=setdiff(Molpart2atomind,Com_PDBind2(:,2)); %��ʾtemModel��û�е�
end
orderCom2=zeros(nMol,3);
for i=1:n_Com_PDBind2
    orderCom2(Com_PDBind2(i,2),:)=[TemComPDB.Model.Atom(Com_PDBind2(i,1)).X ...
        TemComPDB.Model.Atom(Com_PDBind2(i,1)).Y TemComPDB.Model.Atom(Com_PDBind2(i,1)).Z];
end



chcom2=[];    % N CA C O
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,ch2) ...
            && ismember(TemComPDB.Model.Atom(i).AtomName,chatom)
        chcom2=[chcom2;i TemComPDB.Model.Atom(i).X TemComPDB.Model.Atom(i).Y TemComPDB.Model.Atom(i).Z];
    end
end

chpdb2=[];
for i=1:nPDB
    if ismember(TemXrayPDB.Model.Atom(i).resSeq,ch2) ...
            && ismember(TemXrayPDB.Model.Atom(i).AtomName,chatom)
        chpdb2=[chpdb2;i TemXrayPDB.Model.Atom(i).X TemXrayPDB.Model.Atom(i).Y TemXrayPDB.Model.Atom(i).Z];
    end
end
[xc2,yc2,Q2]=TQofB2A(chpdb2(:,2:4),chcom2(:,2:4));
part2X=orderCom2(Molpart2atomind,:);
TQpart2=part2X-repmat(yc2,size(part2X,1),1);
TQpart2=TQpart2*Q2;
TQpart2=TQpart2+repmat(xc2,size(part2X,1),1);
WhX(Molpart2atomind,:)=TQpart2;
end
if partn>=3
Molpart3atomind=[];
for i=1:nMol
    if ismember(TemModel.Model.Atom(i).resSeq,part3)
        Molpart3atomind=[Molpart3atomind;i];        
    end
end
nMolpart3atom=size(Molpart3atomind,1);

Compart3atomind=[];
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,part3)
        Compart3atomind=[Compart3atomind;i];        
    end
end
nCompart3atom=size(Compart3atomind,1);
% ��ȷ��ŵļ�������
Com_PDBind3=[];
for i=1:nCompart3atom
    for j=1:nMolpart3atom
        if strcmp(TemComPDB.Model.Atom(Compart3atomind(i)).AtomName,TemModel.Model.Atom(Molpart3atomind(j)).AtomName) ...
                && TemComPDB.Model.Atom(Compart3atomind(i)).resSeq==TemModel.Model.Atom(Molpart3atomind(j)).resSeq
            Com_PDBind3=[Com_PDBind3;Compart3atomind(i) Molpart3atomind(j)];
        end
    end
end
n_Com_PDBind3=size(Com_PDBind3,1);

if n_Com_PDBind3~=nMolpart3atom
    error('Some atoms are not matched in part3')
    a3=setdiff(Molpart3atomind,Com_PDBind3(:,2)); %��ʾtemModel��û�е�
end
orderCom3=zeros(nMol,3);
for i=1:n_Com_PDBind3
    orderCom3(Com_PDBind3(i,2),:)=[TemComPDB.Model.Atom(Com_PDBind3(i,1)).X ...
        TemComPDB.Model.Atom(Com_PDBind3(i,1)).Y TemComPDB.Model.Atom(Com_PDBind3(i,1)).Z];
end


chatom={'N' 'CA' 'C' 'O'};
chcom3=[];    % N CA C O
for i=1:nCom
    if ismember(TemComPDB.Model.Atom(i).resSeq,ch3) ...
            && ismember(TemComPDB.Model.Atom(i).AtomName,chatom)
        chcom3=[chcom3;i TemComPDB.Model.Atom(i).X TemComPDB.Model.Atom(i).Y TemComPDB.Model.Atom(i).Z];
    end
end

chpdb3=[];
for i=1:nPDB
    if ismember(TemXrayPDB.Model.Atom(i).resSeq,ch3) ...
            && ismember(TemXrayPDB.Model.Atom(i).AtomName,chatom)
        chpdb3=[chpdb3;i TemXrayPDB.Model.Atom(i).X TemXrayPDB.Model.Atom(i).Y TemXrayPDB.Model.Atom(i).Z];
    end
end
[xc3,yc3,Q3]=TQofB2A(chpdb3(:,2:4),chcom3(:,2:4));
part3X=orderCom3(Molpart3atomind,:);
TQpart3=part3X-repmat(yc3,size(part3X,1),1);
TQpart3=TQpart3*Q3;
TQpart3=TQpart3+repmat(xc3,size(part3X,1),1);
WhX(Molpart3atomind,:)=TQpart3;
end

 pdb_change_xyz(WhX,ModelPDBID,OutputPDBID)
 
 
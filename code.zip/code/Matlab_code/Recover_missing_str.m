clear all;
clc;
close all;


addpath(genpath('code'));
addpath('hanso');
addpath('tt');
addpath(genpath('matrix_completion'));
addpath(genpath('proteins'));
load 'ainfo.mat'

% Number of BFGS iterations
gd_tol  = 10^-9;
cg_iter = 500;
f = [10 10 10 10 10]; % [f_hb, f_tau, f_tal, f_vdw, f_tas]
delta=0;


fprintf('==========================================================================\n')
     
protein_name='1sy9';
%protein_name='5h7p';
%protein_name='1jor';
%protein_name='1nmv';
%protein_name='1ssn';
%protein_name='3phy';
%protein_name='1crp';
%protein_name='2rmk';
%protein_name='1blq';
% protein_name='1ap4';
                     

tstart=tic;
   

in_hbond_file = '';
in_max_res = [];
in_min_res = [];

switch protein_name
    case '1sy9'
        in_seq_file   = '1sy9.seq';
        in_upl_file   = {'1sy92.upl','1sy9.upl'};
        in_ang_file   = '';
        knownind=[1:74 81:147];
        missind=[75:80 148];
        XrayPDB='1ctr.pdb';
    case '5h7p'
        in_seq_file   = '5h7p.seq';
        in_upl_file   = {'5h7p2.upl','5h7p.upl'};
        in_ang_file   = '5h7p.aco';
        knownind=[1:64 76:167];
        missind=65:75;
        XrayPDB='2rkk.pdb';
    case '1jor'
        in_seq_file   = '1jor.seq';
        in_upl_file   = {'1jor2.upl','1jor.upl'};
        in_ang_file   = '1jor.aco';
        knownind=6:141;
        missind=[1:5 142:149];
        XrayPDB='1ey4.pdb';
    case '1nmv'
        in_seq_file   = '1nmv.seq';
        in_upl_file   = {'1nmv2.upl','1nmv.upl'};
        in_ang_file   = '1nmv.aco';
        knownind=[6:39 45:163];
        missind=[1:5 40:44];
        XrayPDB='2zr4.pdb';
    case '1ssn'
        in_seq_file   = '1ssn.seq';
        in_upl_file   = {'1ssn.upl'};
        in_ang_file   = '1ssn.aco';
        knownind=16:136;
        missind=1:15;
        XrayPDB='2sak.pdb';
    case '3phy'
        in_seq_file   = '3phy.seq';
        in_upl_file   = {'3phy2.upl','3phy.upl'};
        in_ang_file   = '3phy.aco';
        knownind=4:125;
        missind=1:3;
        XrayPDB='1gsv.pdb';
     case '1crp'
        in_seq_file='1crp.seq';
        in_upl_file={'1crp2.upl','1crp.upl'};
        in_ang_file='1crp.aco';
        knownind=[1:30 38:166];
        missind=31:37;
        XrayPDB='5wlb.pdb';
      case '2rmk'
        in_seq_file   = '2rmk.seq';
        in_upl_file   = {'2rmk.upl'};
        in_ang_file   = '';
        knownind=1:177;
        missind=178:184;
        XrayPDB='2vrw.pdb';
      case '1blq'
        in_seq_file   = '1blq.seq';
        in_upl_file   = {'1blq.upl'};
        in_ang_file   = '1blq.aco';
        knownind=[7:87];
        missind=[1:6 88:90];
        XrayPDB='1avs.pdb';
      case '1ap4'
        in_seq_file   = '1ap4.seq';
        in_upl_file   = {'1ap4.upl'};
        in_ang_file   = '1ap4.aco';
        knownind=[1:66 70:89];
        missind=67:69;
        XrayPDB='3sd6.pdb';
end

protein_path = ['proteins/' protein_name '/'];
fprintf('*************************************************************************\n');
fprintf('Protein: %s\n', protein_name);
fprintf('-Reading input files...\n')
% Reading input data
%==========================================================================
seq_file = [protein_path in_seq_file];
[seq, num] = seq_reader(seq_file);
max_res = max(num);
min_res = min(num);
    
num_upl = size(in_upl_file, 2);
upl_file = cell(1, num_upl);
for i = 1:num_upl
    upl_file{i} = [protein_path in_upl_file{i}];
end
if ~isempty(in_hbond_file)
    hbond_file = [protein_path in_hbond_file];
    hbond_write_file = [protein_path protein_name '_hbo.upl'];
    hbond_reader(hbond_file,hbond_write_file);
    num_upl = num_upl + 1;
    upl_file{num_upl} = hbond_write_file;
end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
raw_up    = cell(1, num_upl);
raw_up_ho = cell(1, num_upl);
temp_min_res = +inf;
temp_max_res = -inf;
for i = 1:num_upl
    raw_up{i} = dist_reader(upl_file{i}, A);
%     temp_min_res = min(temp_min_res, min([raw_up{i}.tres raw_up{i}.sres]));
%     temp_max_res = max(temp_max_res, max([raw_up{i}.tres raw_up{i}.sres]));
end
% if isempty(in_min_res)
%     min_res = max(temp_min_res-1, min_res);
% else
%     min_res = in_min_res;
% end
% if isempty(in_max_res)
%     max_res = min(temp_max_res+1, max_res);
% else
%     max_res = in_max_res;
% end
    
% Remove informationless (w/o any constraints)
% parts from and N- and C-terminus
% ind_del_N = num < min_res;
% ind_del_C = num > max_res;
% ind_del   = ind_del_N | ind_del_C;
% seq(ind_del) = [];
% num(ind_del) = [];
    
% dihedral angle constraints
ang_file = [protein_path in_ang_file];
[phi_cons, psi_cons] = ang_reader(ang_file, num);

%add begin
phi_cons(knownind,1)=-180;
phi_cons(knownind,2)=180;
psi_cons(knownind,1)=-180;
psi_cons(knownind,2)=180;
%add end

%==========================================================================
trend = toc(tstart);
fprintf('\tdone: %4.1f sec\n', trend)
fprintf('-Sampling a random molecule...\n')
% Generating a random structure
%==========================================================================
[phi, psi] = ang_sampler(seq,phi_cons,psi_cons);

 [rand_X, Comp] = ibuildprot(seq,num,phi,psi,A);
 [U, Comp.cliq_dims] = reducer(rand_X,Comp); 
if exist(ang_file, 'file')
    [ang_lo_cons, ang_up_cons] = ang_dist_conmaker(phi_cons,psi_cons,Comp);
end


%==========================================================================
trand = toc(tstart);
fprintf('\tdone: %4.1f sec\n',trand - trend)
fprintf('-Forming constraints...\n')
% Generating upper and lower bounds constraints
%==========================================================================
start = 0;
up_bounds = nan(50000,4);
for i = 1:num_upl
    temp_upl = upper_maker(raw_up{i}, Comp);
    up_bounds(start+1:start+size(temp_upl,1),:) = temp_upl;
    start = start + size(temp_upl,1);
end
up_bounds(isnan(up_bounds(:,1)), :) = [];
% adding torsion-angle constraints
if exist(ang_file, 'file')
   up_bounds = [up_bounds; ang_up_cons];
end

%%%%%% add begin
knownAtomind=[];
nComp=length(Comp.atom_names);
for i=1:nComp
    if ismember(Comp.residue(i),knownind)
        knownAtomind=[knownAtomind;i];
    end
end
knownupind=[];
for i=1:size(up_bounds,1)
    if ismember(up_bounds(i,1),knownAtomind) && ismember(up_bounds(i,2),knownAtomind)
        knownupind=[knownupind;i];
    end
end
up_bounds(knownupind,:)=[];
up0ind=[];
for i=1:size(up_bounds,1)
    if up_bounds(i,3)==0
        up0ind=[up0ind;i];
    end
end
up_bounds(up0ind,:)=[];
%%%%%% add end
 % equality cons
 eq_cons = equality_cons_former(rand_X,Comp);
 % vdw bounds
 vdw_bounds = vdw_bound_maker(Comp);
    
 lo_bounds     = vdw_bounds;
 if exist(ang_file, 'file')
    lo_bounds    = [lo_bounds; ang_lo_cons];
end
%=========================================================================
% %
num_atom=size(Comp.atom_names,1);
cons_column=[eq_cons;up_bounds(:,1:3)];
ori_d=sparse(cons_column(:,1),cons_column(:,2),cons_column(:,3),num_atom,num_atom);
ori_d=full(ori_d);
d=ori_d+ori_d';
tbounds = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tbounds - trand)
fprintf('Forming Triangle inequality constraint...\n')
fprintf('\n');

% add begin
XPDBtemp=pdbread(XrayPDB);
XrayX=[];
nX=length(XPDBtemp.Model.Atom);
for i=1:nX
    XrayX=[XrayX;XPDBtemp.Model.Atom(i).X XPDBtemp.Model.Atom(i).Y XPDBtemp.Model.Atom(i).Z];
end
XrayD=X2D(XrayX);

Comp_Xind=[];

for i=1:nComp
    for j=1:nX
        if strcmp(Comp.atom_names(i),XPDBtemp.Model.Atom(j).AtomName) ...
                && Comp.residue(i)==XPDBtemp.Model.Atom(j).resSeq
            Comp_Xind=[Comp_Xind;i j];
        end
    end
end
n2ind=size(Comp_Xind,1);
eq0=zeros(size(d));
for i=1:n2ind
    for j=1:n2ind
        d(Comp_Xind(i,1),Comp_Xind(j,1))=XrayD(Comp_Xind(i,2),Comp_Xind(j,2));
        eq0(Comp_Xind(i,1),Comp_Xind(j,1))=XrayD(Comp_Xind(i,2),Comp_Xind(j,2));
    end
end  
% add end

Dtri= tri3stri(d);
ttriang = toc(tstart);
fprintf('\tdone: %4.1f sec\n',ttriang - tbounds)
disp('*********************************************************************')
sample_rate = 10*5/num_atom;

%[Dret,Dretsample ] = triChange(Dtri_intitial, d,num_atom ); % 0814
[Dret,Dretsample ] = triChange( Dtri, d,num_atom );

Drecover = randmsamplesym(Dretsample,sample_rate);
DrecoverF = Drecover+d;
DrecoverF2=DrecoverF.^2;
% %
% r=5;
% xps=1e-5;
% mu=0.01;
% ro=1.4;
% Imax=100;
% X=IRLNM_QR(DrecoverF2,r,xps,mu,ro,Imax,10,3);
%X=IRLNM_QR(M,r,xps,mu,ro,Imax,theta,S);
% % refine
%  [Xiter,Info] = refined1(xca,CAD0);
%  Xiter=Xiter';
% scaledASD
ttriang_then = toc(tstart);
fprintf('solving the MC problem by ASD...\n')
fprintf('\n');
opts = default_opts();
[m,n]=size(DrecoverF2);
r=5;
[II,JJ]=find(DrecoverF2);
Omega2=sub2ind([m,n],II,JJ);
data2=DrecoverF2(Omega2);
% start2 = make_start_x('ASD',m,n,r,Omega2,data2);
% [Mout2, Out2] = ASD(m,n,r,Omega2,data2,start2,opts);
start2 = make_start_x('ScaledASD',m,n,r,Omega2,data2);
[Mout2, Out2] =ScaledASD(m,n,r,Omega2,data2,start2,opts);
tcompu_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tcompu_end - ttriang_then)
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
% ASD_post_processing
fprintf('Post processing...\n')
fprintf('\n');
%Mout2=X;                               %%%%
H=eye(num_atom)-ones(num_atom,num_atom)/num_atom;
G2=-1/2*H*Mout2*H;
[VZ2,LZ2]=eigb(G2);
LZ2=real(LZ2);
LZ2(LZ2<0)=0;
Z2=LZ2^0.5*VZ2';
rawX=Z2(1:3,:); 
disp('*********************************************************************')
% Analysis of the output
%==========================================================================
fprintf('Violations (raw)\n')

% eq_con

[a,b,c]=find(eq0);
check_eq_cons =[a b c];
upind=[];
for i=1:size(a,1)
    for j=1:size(up_bounds,1)
    if a(i)==up_bounds(j,1) && b(i)==up_bounds(j,2)
        upind=[upind;i];
    end
    end
end
check_eq_cons(upind,:)=[];
%add tri
[tri1,tri2,tri3]=find(Drecover);
tri4=zeros(size(tri1,1),1);
bondtri=[tri1 tri2 tri3 tri4];
up_bounds=[up_bounds;bondtri];

report = protchecker(rawX(1:3,:),Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')
%==========================================================================
% Post-processing
%==========================================================================
fprintf('Post-Processing...\n')
fprintf('\n');
f = [10 10 10 10 10];
W = [2 1 1 -1];

% Phase I - GD
% Refinement by HANSO
[pX, hinfo] = hanso_post_processing(rand_X, rawX, Comp, lo_bounds, up_bounds, W, f);
fprintf('Violations (GD-I)\n')
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
%---------------------------------------------------------------------------
% simple fix using the fact that most residues lie on the left half of
% Ramachandran plot
if sum(p_report.phi(~isnan(p_report.phi)) > 0) > 0.5*length(p_report.phi)
    pX(1,:) = -pX(1,:);
end
p_report = protchecker(pX,Comp,check_eq_cons,lo_bounds,up_bounds,0);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pX,Comp,p_report.chiral);
fprintf('Violations (after fixing chiralities)\n')
p_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
disp('*********************************************************************')

[pXc, c_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
fprintf('Violations (GD-II)\n')
pc_report = protchecker(pXc,Comp,check_eq_cons,lo_bounds,up_bounds,1);
fprintf('\nCorrecting chiralities:\n')
pXc = chirality_correction(pXc,Comp,pc_report.chiral);
disp('*********************************************************************')
[fX, wh_info] = hanso_post_processing(rand_X,pXc,Comp,lo_bounds,up_bounds,W,f);
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 fprintf('\nViolations (FINAL)\n')
 fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
 final_report = protchecker(fX,Comp,check_eq_cons,lo_bounds,up_bounds,1);
 disp('*********************************************************************')
%==========================================================================


tpost_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',tpost_end-tcompu_end)
disp('*********************************************************************')
fprintf('\n Writing pdb\n')
pdb_writer_file=[ protein_name  '.pdb'];
pdb_writer(pdb_writer_file,fX,Comp)
twrite_end = toc(tstart);
fprintf('\tdone: %4.1f sec\n',twrite_end-tpost_end)
fprintf('==========================================================================\n')
fprintf('\tOverall time: %4.1f sec\n',toc(tstart))


fprintf('done!\n')
fprintf('==========================================================================\n')

function mmm=cmp_ave(d,Dtri,ddmm)
   n=size(d,1);
   mmm=zeros(size(d));
   for i=1:n
       for j=1:n
           if d(i,j)==0&&i~=j
               temp=ddmm{i,j};
               mmm(i,j)=(Dtri(temp(1,1),temp(1,2))+Dtri(temp(2,1),temp(2,2))+...
                  abs(Dtri(temp(1,1),temp(1,2))-Dtri(temp(2,1),temp(2,2))))/2;
           else
               mmm(i,j)=d(i,j);
           end
       end
   end
end
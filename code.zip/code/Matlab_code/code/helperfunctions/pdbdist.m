function  [dists, pdbstruct]= pdbdist(ID,threshold)
%  PDBDIST calculates distances between atoms in a PDB structure 
%  and plots them.
%    
%   PDBDIST(PDBID,DIST) allows you to specify the threshold distance in
%   Angstroms. The default is INF, which gives the full atoms. 
%
%   This function is based on the rewriting of matlab's default function
%   PDBDISTPLOT.M but there are lots of changing here.
%
%   See also GETPDB, MOLVIEWER, PDBREAD, PROTEINPLOT, PROTEINPROPPLOT,
%   RAMACHANDRAN.

%   WARNING(!!!!): 0 elements on the diagonal is physical, but those 
%   off-diagonal means missing elements. You can change the latter 
%   into NAN. This effect also shows on the plot.

%   by Hu2, 2012-10-15

bioinfochecknargin(nargin,1,mfilename);
if nargin < 2
    threshold = inf; % 7 is the value to mimic NMR experiments.
end

%read the pdb entry
%ID must either a structure, a pdb file, or a valid PDBID.
try
    if (~isstruct(ID))
        if exist(ID,'file')
            pdbstruct = pdbread(ID);
        else
            pdbstruct = getpdb(ID);
        end
    else
        pdbstruct = convertpdbstruct(ID, mfilename);            
    end
catch theErr
    if ~isempty(strfind(theErr.identifier,'getpdb')) 
        rethrow(theErr);
    end
    error('Bioinfo:pdbdistplot:InvalidInput',...
        'The input should be a structure of data, a PDB file, or a valid PDB ID.');
end

% Threshold must be numeric
if ~isnumeric(threshold)
    error('Bioinfo:pdbdistplot:NotANumeric',...
        'THRESHOLD must be a numeric value.');
end

% Get the first model in pdbstruct
if isfield(pdbstruct, 'Model')
    modelstruct = pdbstruct.Model(1);
else
    error('Bioinfo:pdbdistplot:NotAtomicCoordinates',...
        'The PDB data did not contain any atomic coordinate record.');
end

% If there are multiple chains, we will look at them separately
numSequences = numel(pdbstruct.Sequence);

% for seq = 1:numSequences % Comment by HU2: only consider the 1st chain
for seq = 1:1
    % get IDs for current chain
    chainID =  pdbstruct.Sequence(seq).ChainID;
    
    % get coords of Atoms and HeterogenAtoms
    chainCoords = [modelstruct.Atom.chainID]' ==chainID;
    
    %%%%%%%%%
    % here I simply consider only Atoms on the backbone
    %%%%%%%%%
    
%     if isfield(modelstruct, 'HeterogenAtom')
%         hetCoords = [modelstruct.HeterogenAtom.chainID]' == chainID;
%         % Create Nx3 matrix of 3D coords
%         coords = [modelstruct.Atom(chainCoords).X modelstruct.HeterogenAtom(hetCoords).X;
%             modelstruct.Atom(chainCoords).Y modelstruct.HeterogenAtom(hetCoords).Y;
%             modelstruct.Atom(chainCoords).Z modelstruct.HeterogenAtom(hetCoords).Z; ]';
% 
%         order = [modelstruct.Atom(chainCoords).resSeq,...
%             modelstruct.HeterogenAtom(hetCoords).resSeq;];
% 
%         % reorder the matrix so that any Het atoms that should be intersperced
%         % with normal atoms are in the correct order.
%         [order, perm] = sort(order);
%         coords = coords(perm,:);
%     else
        % Create Nx3 matrix of 3D coords
        coords = [modelstruct.Atom(chainCoords).X;
            modelstruct.Atom(chainCoords).Y;
            modelstruct.Atom(chainCoords).Z; ]';
        
        order = [modelstruct.Atom(chainCoords).resSeq];
%     end
        
    % calculating and plotting pairwise distances is memory intensive. Stop
    % if we have more than 3000 coordinates.
    if numel(order) > 30000
        % we could break the model up into blocks to deal with the memory
        % required for very large proteins, but even so we will still have to
        % calculate all the pairwise distances which will take a long time.
        if numSequences > 1
            warning('Bioinfo:pdbdistplot:ChainTooLong',...
                'Chain %d is too long.',seq);
            continue
        else
            error('Bioinfo:pdbdistplot:ModelTooBig',...
                'Model is too large.')
        end
    end
    
    % make sure that we start counting at 1
    if order(1) < 1
        order = order + (1-order(1));
    end

    % calculate pairwise distances. 
    distances = pdist(coords);
    
    % figure out which atoms are close by threshold
    closeAtoms = distances>threshold;
    distances(closeAtoms) = 0; % or NAN???????? choose it by yourself!
    distances2 = distances;
    distances2(closeAtoms) = nan;
    dists = squareform(distances);
    dists2 = squareform(distances2);
%     
%     figure
%     % squareform takes pdist output and turns it into a square matrix.
%     imagesc(dists);
% %     spy(dists)
%     axis image
%     colormap(1-hot); % change the color by yourself, or simply comment it off
%     title(sprintf('Inter-atomic distances less than %.2f Angstroms apart',...
%         threshold) );
    
    
end



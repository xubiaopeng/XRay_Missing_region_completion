% T and Q of moving B to A 
function [xc,yc,Q]=TQofB2A(XA,XB)

if size(XA,1)~=size(XB,1)
    error('The size of XA and XB is not equal')
end

num_atoms=size(XA,1);
xc = sum(XA) / num_atoms;
yc = sum(XB) / num_atoms;
T=xc-yc;
% move X's center to original point
XX(:, 1) = XA(:, 1) - xc(1);
XX(:, 2) = XA(:, 2) - xc(2);
XX(:, 3) = XA(:, 3) - xc(3);
% move Y's center to original point
YY(:, 1) = XB(:, 1) - yc(1);
YY(:, 2) = XB(:, 2) - yc(2);
YY(:, 3) = XB(:, 3) - yc(3);

C = YY' * XX;
Cdet = det(C);
[U, S, V] = svd(C);
uv = det(U)*det(V);
% Si=[1 0 0;0 1 0;0 0 -1];
% if Cdet>0 || ((Cdet==0) && (uv>0)) 
     Q = U * V';

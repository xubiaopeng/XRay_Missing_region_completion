function pdb_change_xyz(or_X,pdb,file_name)
A=pdbread(pdb);
num=size(or_X,1);
fid = fopen(file_name,'wt');
if fid < 0
    error('there was an error opening the file...')
end
try    
    for i = 1:num
        tname=A.Model.Atom(i).AtomName;
        amino_3L=A.Model.Atom(i).resName;
        residue=A.Model.Atom(i).resSeq;
        X=or_X(i,1);
        Y=or_X(i,2);
        Z=or_X(i,3);
        fprintf(fid,'ATOM%7d  %-3s%4s%6d%12.3f%8.3f%8.3f\n',...
            i,tname,amino_3L,residue,X,Y,Z);
    end         
    fprintf(fid,'TER\n');
    fprintf(fid,'END');
    fclose(fid);
catch except
    fclose(fid);
    delete(file_name);
    rethrow(except);
end
end
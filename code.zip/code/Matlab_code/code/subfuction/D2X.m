function X=D2X(dists)
% ���������󣬵ó��������
% editor lzc  20151217

N=length(dists); %distsΪʵ�ʾ���
G=nan(N);
Djk2=(norm(dists,'fro'))^2;
for i=1:N
    for j=1:N
        G(i,i)=(norm(dists(i,:),2))^2/N-Djk2/(2*N^2);        
    end
end

for i=1:N
    for j=1:N
        if i~=j
            G(i,j)=(G(i,i)+G(j,j)-dists(i,j)^2)/2;
        end
    end
end

[U,S,V]=svd(G);
S=S(:,1:3);
X=U*sqrt(S);
end 